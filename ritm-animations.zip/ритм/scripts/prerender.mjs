// После `vite build` вставляет готовый HTML лендинга в dist/index.html и пишет robots.txt и sitemap.xml.
// Если что-то пойдёт не так, сайт всё равно работает: остаётся обычная страница с загрузкой через JavaScript.
import { readFileSync, writeFileSync, rmSync } from "node:fs";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const indexPath = resolve(root, "dist/index.html");
const siteUrl = (process.env.SITE_URL || process.env.URL || "").replace(/\/+$/, "");

try {
  const { render } = await import(pathToFileURL(resolve(root, "dist-ssr/prerender.js")).href);
  const html = render();
  const page = readFileSync(indexPath, "utf8");
  if (!page.includes("<!--prerender-->")) throw new Error("нет метки <!--prerender--> в index.html");
  writeFileSync(indexPath, page.replace("<!--prerender-->", `<div id="prerender">${html}</div>`));
  console.log(`prerender: лендинг вставлен в dist/index.html (${Math.round(html.length / 1024)} КБ HTML)`);
} catch (e) {
  console.warn("prerender: пропущено —", e.message);
} finally {
  rmSync(resolve(root, "dist-ssr"), { recursive: true, force: true });
}

// robots.txt — всегда; sitemap.xml — только если известен полный адрес сайта (на Netlify — переменная URL)
const robots = ["User-agent: *", "Allow: /", "Disallow: /app", "Disallow: /api/"];
if (siteUrl) {
  robots.push(`Sitemap: ${siteUrl}/sitemap.xml`);
  writeFileSync(resolve(root, "dist/sitemap.xml"), `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>${siteUrl}/</loc><changefreq>weekly</changefreq><priority>1.0</priority></url>
</urlset>
`);
}
writeFileSync(resolve(root, "dist/robots.txt"), robots.join("\n") + "\n");
